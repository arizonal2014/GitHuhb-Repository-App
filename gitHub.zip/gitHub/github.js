class Github {

  constructor() {
    this.client_id = 'ee3ddafaacbd42f8e0b6';
    this.client_secret = 'f18b5e143a7800487f3d9a6d8ba4cc4f711c6bb0';
    this.repo_count = 4;
  }


  async getRepo(userText) {

    const repoResponse = await fetch(`https://api.github.com/search/repositories?q=${userText}&client_id=${this.client_id}&client_secret=${this.client_secret}&per_page=${this.repo_count}`);

    const repo = await repoResponse.json();

    return {

      repo: repo.items
    }


  }



}